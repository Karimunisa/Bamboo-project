def lambda_handler(event, context):
    print('Hello, logs!')
    return 'great success'